/**
 * Name:
 * Matric. No:
 */

public class Friends {
  public static void main(String args[]) {
    
  }
}
