/**
 * Name:
 * Matric. No:
 */

public class Groceries {
  public static void main(String args[]) {
    
  }
}
