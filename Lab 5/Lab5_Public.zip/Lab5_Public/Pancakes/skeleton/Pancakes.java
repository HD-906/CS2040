/**
 * Name:
 * Matric. No:
 */

public class Pancakes {
  public static void main(String args[]) {
    
  }
}
