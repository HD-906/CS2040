/**
 * Name:
 * Matric. No:
 */

public class Macarons {
  public static void main(String args[]) {
    
  }
}
