/**
 * Name:
 * Matric. No:
 */

public class Palindromes {
  public static void main(String args[]) {
    
  }
}
