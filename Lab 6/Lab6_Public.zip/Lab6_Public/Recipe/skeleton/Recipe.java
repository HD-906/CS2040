/**
 * Name:
 * Matric. No:
 */

public class Recipe {
  public static void main(String args[]) {
    
  }
}
