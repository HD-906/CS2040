/**
 * Name:
 * Matric. No:
 */

public class Cinema {
  public static void main(String args[]) {
    
  }
}
