/**
 * Name:
 * Matric. No:
 */

public class School {
  public static void main(String args[]) {
    
  }
}
