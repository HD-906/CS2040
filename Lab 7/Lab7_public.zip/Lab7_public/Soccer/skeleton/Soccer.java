/**
 * Name:
 * Matric. No:
 */

public class Soccer {
  public static void main(String args[]) {
    
  }
}
