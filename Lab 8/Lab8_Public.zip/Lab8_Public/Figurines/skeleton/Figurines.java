/**
 * Name:
 * Matric. No:
 */

public class Figurines {
  public static void main(String args[]) {
    
  }
}
