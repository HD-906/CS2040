/**
 * Name:
 * Matric. No:
 */

public class Monsters {
  public static void main(String args[]) {
    
  }
}
